Import  respository/download the attached file into your system 
install node.js (check you system specification) 
Open the download folder or respository file in your system 
type command in terminal cd durhampolice 
then type npm install in terminal 
type npm run dev
Link  to the local host (http://localhost:5173/)
Go to new terminal type cd server
connect to server type npm start 
Download xampp control panel 
import durhampolice.sql.gz in xampp 
