import React from 'react'

const AllIncidentLog = () => {
  return (
    <div>AllIncidentLog</div>
  )
}

export default AllIncidentLog