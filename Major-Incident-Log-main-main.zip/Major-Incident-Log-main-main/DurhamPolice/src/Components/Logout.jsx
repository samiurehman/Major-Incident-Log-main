import React from 'react'

const Logout = () => {
  return (
    <div>Log out</div>
  )
}

export default Logout