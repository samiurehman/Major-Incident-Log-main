-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 28, 2024 at 11:56 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `durhampolice`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `email` varchar(90) NOT NULL,
  `password` varchar(140) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `email`, `password`) VALUES
(1, 'admin@gmail.com', '12345'),
(2, 'sami@gmail.com', '123456'),
(3, 'james@gmail.com', '0987');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `name`, `email`, `password`) VALUES
(14, 'Sami Rehman', 'samirehman@gmail.com', '$2b$10$3jLrCx7zLLSuIqnAWjGtiet6rWSZfJA5Ks9SZ1u6oo/Z6EfDq6Jmm'),
(15, 'damola', 'damola@gmail.com', '$2b$10$91afFr2uYpsw6E3Hz1CoIeSE.n2DO1T2CT09tyA2IH7/hsQj1DnHO');

-- --------------------------------------------------------

--
-- Table structure for table `incident category`
--

CREATE TABLE `incident category` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `incident category`
--

INSERT INTO `incident category` (`id`, `name`) VALUES
(62, 'Murder'),
(63, 'Murder');

-- --------------------------------------------------------

--
-- Table structure for table `incidentlogs`
--

CREATE TABLE `incidentlogs` (
  `id` int(11) NOT NULL,
  `dateTimeOfIncident` datetime NOT NULL,
  `natureOfIncident` text NOT NULL,
  `weatherCondition` varchar(225) NOT NULL,
  `locationOfIncident` varchar(225) NOT NULL,
  `dateTimeOfVisit` datetime NOT NULL,
  `detailsOfPerson` text NOT NULL,
  `reasonForAttendance` text NOT NULL,
  `protectiveClothingWorn` text NOT NULL,
  `officerCompletingLog` varchar(255) NOT NULL,
  `leaveTime` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `incidentlogs`
--

INSERT INTO `incidentlogs` (`id`, `dateTimeOfIncident`, `natureOfIncident`, `weatherCondition`, `locationOfIncident`, `dateTimeOfVisit`, `detailsOfPerson`, `reasonForAttendance`, `protectiveClothingWorn`, `officerCompletingLog`, `leaveTime`) VALUES
(1, '2024-04-17 22:52:14', 'ioo', 'iui', 'ouop', '2024-04-17 22:52:14', 'jioi', 'iouo', 'iooiu', 'iiouo', '2024-04-17 21:54:49'),
(2, '2024-04-09 21:52:14', 'ouu09', 'i09898', 'p9u980', '2024-04-02 21:52:14', 'opipi', 'opuoiup', 'uou09', 'u090', '2024-04-16 21:52:14');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `incident category`
--
ALTER TABLE `incident category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `incidentlogs`
--
ALTER TABLE `incidentlogs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `incident category`
--
ALTER TABLE `incident category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT for table `incidentlogs`
--
ALTER TABLE `incidentlogs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
